Feature: DHA-Person-Verification-Service

  Scenario Outline: Execute|Operation|statusCode|200|OK
    Given DHA: ( <serviceName> ) service is up and running

    Examples: 
      | serviceName          |
      | "PersonVerification" |

  Scenario Outline: Execute|Operation|statusCode|400|Bad Request
    Given DHA: ( <serviceName> ) service is up and running

    Examples: 
      | serviceName |

  # | "PersonVerificationModel" |
  Scenario Outline: Execute|Operation|statusCode|500|Fault Handling
    Given DHA: ( <serviceName> ) service is up and running

    Examples: 
      | serviceName |
      #| "PersonVerificationFault" |
