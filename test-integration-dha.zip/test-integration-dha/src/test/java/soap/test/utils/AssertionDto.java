package soap.test.utils;

public class AssertionDto {

	public String path = null;
	public String expected = null;
	public String actual = null;
	public String decision = null;
}
