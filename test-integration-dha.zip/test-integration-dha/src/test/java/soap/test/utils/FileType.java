package soap.test.utils;

public enum FileType {
    JKS ,
    PKCS12
}
